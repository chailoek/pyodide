Plot 21 has length 6

.. plot::

    plt.plot(range(6))

