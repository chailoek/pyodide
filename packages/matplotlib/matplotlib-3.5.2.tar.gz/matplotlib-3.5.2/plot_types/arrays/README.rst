.. _array_plots:

Plots of arrays and fields
--------------------------

Plotting for arrays of data ``Z(x, y)`` and fields ``U(x, y), V(x, y)``.