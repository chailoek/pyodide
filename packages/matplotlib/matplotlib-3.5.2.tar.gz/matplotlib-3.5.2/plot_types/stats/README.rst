.. _stats_plots:

Statistics plots
----------------

Plots for statistical analysis.