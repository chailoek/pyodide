.. _plot_types:

.. redirect-from:: /tutorials/basic/sample_plots

Plot types
==========

Overview of many common plotting commands in Matplotlib.

Note that we have stripped all labels, but they are present by default.
See the `gallery <../gallery/index.html>`_ for many more examples and
the `tutorials page <../tutorials/index.html>`_ for longer examples.