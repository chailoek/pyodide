.. _basic_plots:

Basic
-----

Basic plot types, usually y versus x.