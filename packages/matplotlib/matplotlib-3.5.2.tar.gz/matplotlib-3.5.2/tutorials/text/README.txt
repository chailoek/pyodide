.. _tutorials-text:

Text
----

matplotlib has extensive text support, including support for
mathematical expressions, truetype support for raster and
vector outputs, newline separated text with arbitrary
rotations, and unicode support. These tutorials cover
the basics of working with text in Matplotlib.
