.. _tutorials-intermediate:

Intermediate
------------

These tutorials cover some of the more complicated classes and functions
in Matplotlib. They can be useful for particular custom and complex
visualizations.
