.. _tutorials-introductory:

Introductory
-------------

These tutorials cover the basics of creating visualizations with
Matplotlib, as well as some best-practices in using the package
effectively.
