.. _tutorials-colors:

Colors
------

Matplotlib has support for visualizing information with a wide array
of colors and colormaps. These tutorials cover the basics of how
these colormaps look, how you can create your own, and how you can
customize colormaps for your use case.

For even more information see the :ref:`examples page <color_examples>`.
